var config = {
	tahun_anggaran : "2021", // Tahun anggaran
	id_daerah : "335", // ID daerah didapat dari https://[nama daerah].sipd.kemendagri.go.id/daerah/main/budget/belanja/2021/giat/unit/[id_daerah]/[id_unit]
	sipd_url : "https://banggaikab.sipd.kemendagri.go.id/", // alamat sipd sesuai kabupaten kota masing-masing
	user_sekda : "xxx", // user sekda
	pass_sekda : "xxx", // password sekda
	user_admin_ssh : "xxx", // username admin SSH
	pass_admin_ssh : "xxx", // password admin SSH
	user_kepala_skpd : "xxx", // user kepala OPD atau camat
	pass_kepala_skpd : "xxx", // password kepala OPD atau camat
	user_operator_sub_kegiatan : "xxx", // username operator sub kegiatan
	pass_operator_sub_kegiatan : "xxx", // password operator sub kegaitan
	url_server_lokal : "https://xxxxxxxxxx.com/wp-admin/admin-ajax.php", // url server lokal
	api_key : "xxxxxxxxxxxxxxxxxxx", // api key server lokal disesuaikan dengan api dari WP plugin
	tapd : [{
		nama: "Andi Nur Asiah, ST, MM",
		nip: "19760119 200312 2 004",
		jabatan: "Kabid. Ekonomi dan Sumber Daya Alam BAPPEDA Kab. Banggai",
	},{
		nama: "MASRAINI, B. Ac.,SE.,MM",
		nip: "19631122 199303 2 005",
		jabatan: "Kepala Bidang Akuntansi BPKAD Kab. Banggai",
	},{
		nama: "Drs. NATALIA PATOLEMBA, M.Si",
		nip: "19741227 199410 1 001",
		jabatan: "Sekretaris BAPENDA Kab. Banggai",
	},{
		nama: "HASBULLAH ADJIBU, S.IP.,ST.,MT",
		nip: "19640805 198610 1 008",
		jabatan: "Kepala Bagian Administrasi Pembangunan SETDA Kab. Banggai",
	},{
		nama: "FARID HASBULAH KARIM, SH.,MH",
		nip: "19710527 199303 1 005",
		jabatan: "Kepala Bagian Hukum SETDA Kab. Banggai",
	},{
		nama: "I DW GEDE SUPATRIAGAMA, ST.,M.Si",
		nip: "19800505 200604 1 015",
		jabatan: "Kepala Bagian Pengadaan Barang dan Jasa SETDA Kab. Banggai",
	}], // nama tim TAPD dalam bentuk array dan object maksimal 8 orang sesuai format SIPD
	tgl_rka : "auto" // pilihan nilai default "auto"=auto generate, false=fitur dimatikan, "isi tanggal sendiri"=tanggal ini akan muncul sebagai nilai default dan bisa diedit
};